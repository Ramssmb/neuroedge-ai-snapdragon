# NeuroEdge AI
### Intelligent, Private & Real-Time AI on Snapdragon®

**Multimodal • On-Device • Privacy-First • Hardware-Accelerated**

NeuroEdge AI is a complete reference implementation of a multimodal AI assistant designed for Snapdragon platforms. It combines local LLM reasoning, speech recognition, computer vision, OCR, and document intelligence with a strong focus on privacy and real-time performance.

---

## Project Highlights

- **Fully modular architecture** – easy to swap real Qualcomm-accelerated models
- **Working HTML prototype** – modern chat UI with text, voice, image & document support
- **Python orchestration engine** – production-ready pipeline
- **Performance dashboard** – latency, memory, on-device indicators
- **Privacy by design** – clear on-device processing badges
- **Snapdragon-ready** – hooks for QNN / SNPE / ONNX Runtime Qualcomm EP

---

## Quick Start (HTML Prototype)

```bash
cd NeuroEdgeAI/web
python3 -m http.server 8080
```

Open **http://localhost:8080** in your browser.

The prototype works completely offline (mock models). It supports:
- Text chat
- Voice input (Web Speech API)
- Image upload + analysis
- Document upload + summarization / Q&A
- Real-time performance metrics
- Privacy status indicators

---

## Full Project Structure

```
NeuroEdgeAI/
├── README.md
├── requirements.txt
├── docs/
│   ├── architecture.md
│   └── snapdragon_optimization.md
├── src/
│   ├── main.py                 # CLI prototype
│   ├── orchestration/
│   │   ├── engine.py           # Central AI Orchestration Engine
│   │   └── router.py
│   ├── models/
│   │   ├── llm.py
│   │   ├── asr.py
│   │   ├── vision.py
│   │   ├── ocr.py
│   │   └── embeddings.py
│   ├── rag/
│   │   └── pipeline.py
│   ├── monitoring/
│   │   └── performance.py
│   └── utils/
│       ├── privacy.py
│       └── hardware.py
├── web/                        # Fully working HTML prototype
│   ├── index.html
│   ├── css/style.css
│   ├── js/app.js
│   └── assets/
├── models/                     # Place quantized models here
└── android/                    # Notes for Android + Snapdragon port
```

---

## Running the Python Backend / CLI

```bash
pip install -r requirements.txt
python -m src.main
```

---

## Snapdragon Deployment Path

1. Quantize models (INT4/INT8) using Qualcomm AI Hub or ONNX Runtime
2. Export to QNN / SNPE format
3. Integrate via Qualcomm AI Engine Direct or ONNX Runtime with Qualcomm Execution Provider
4. Replace mock classes in `src/models/` with real accelerated inference
5. Build Android app (Kotlin + Jetpack Compose or Flutter) using the same orchestration logic

See `docs/snapdragon_optimization.md` for detailed guidance.

---

## Key Principles

- **Private by Design** – sensitive data stays on device
- **Fast by Design** – Snapdragon NPU / GPU / CPU acceleration
- **Multimodal by Design** – text • voice • image • document

---

## License

MIT – free to use, modify, and deploy.
