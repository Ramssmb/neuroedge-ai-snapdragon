/**
 * NeuroEdge AI – Working HTML Prototype
 * Simulates the full multimodal on-device pipeline in the browser.
 * In production this would call the Python orchestration engine or native Snapdragon APIs.
 */

(() => {
  // ---------- State ----------
  const state = {
    messages: [],
    pendingImage: null,
    pendingDoc: null,
    pendingDocText: null,
    isProcessing: false,
    stats: {
      lastLatency: 0,
      avgLatency: 0,
      total: 0,
      onDeviceRatio: 1,
      history: [],
    },
  };

  // ---------- DOM ----------
  const $ = (sel) => document.querySelector(sel);
  const messagesEl = $("#messages");
  const inputEl = $("#user-input");
  const sendBtn = $("#send-btn");
  const imgBtn = $("#img-btn");
  const docBtn = $("#doc-btn");
  const voiceBtn = $("#voice-btn");
  const imgInput = $("#img-input");
  const docInput = $("#doc-input");
  const attachmentsEl = $("#attachments");
  const clearBtn = $("#clear-btn");
  const privacyToast = $("#privacy-toast");
  const privacyToastText = $("#privacy-toast-text");

  // ---------- Mock Model Responses (mirrors Python backend) ----------
  function mockLLM(prompt, context = {}) {
    const lower = (prompt || "").toLowerCase();

    if (context.docText) {
      return (
        "**Document Analysis (On-Device)**\n\n" +
        "**Concise Summary**\n" +
        "• Confidential internal document related to NeuroEdge AI evaluation\n" +
        "• Focuses on privacy, low-latency, and multimodal requirements\n" +
        "• Clear action items and deadlines present\n\n" +
        "**Key Points**\n" +
        "1. No unnecessary cloud transmission of user data\n" +
        "2. Sub-second response target for common queries\n" +
        "3. Support for text, voice, image, and documents\n\n" +
        "**Action Items**\n" +
        "• Finalize model quantization by end of month\n" +
        "• Complete performance benchmarking on target hardware\n" +
        "• Prepare demo for stakeholders\n\n" +
        "All extraction and reasoning stayed on this device."
      );
    }

    if (context.hasImage) {
      return (
        "**Visual Analysis (On-Device)**\n\n" +
        "I can see a clear image. The scene contains recognizable objects and good lighting.\n\n" +
        "**Detected elements**\n" +
        "• Main subject with high confidence\n" +
        "• Background context identified\n" +
        "• Overall composition is well-defined\n\n" +
        "Ask me any specific question about what is in the image — I will answer using only local vision + LLM processing."
      );
    }

    if (lower.includes("summarize") || lower.includes("summary")) {
      return (
        "**Summary generated on-device**\n\n" +
        "• Core ideas extracted\n" +
        "• Supporting details retained\n" +
        "• Actionable takeaways highlighted\n\n" +
        "This response was produced by the local LLM without any cloud round-trip."
      );
    }

    if (lower.includes("hello") || lower.includes("hi ") || lower === "hi") {
      return (
        "Hello! I'm running fully on-device. Your conversations, images, and documents never leave this session.\n\n" +
        "You can:\n" +
        "• Chat with me in natural language\n" +
        "• Upload an image for visual understanding\n" +
        "• Upload a document for private summarization & Q&A\n" +
        "• Use the microphone for voice input\n\n" +
        "How can I help you today?"
      );
    }

    if (lower.includes("privacy") || lower.includes("on-device") || lower.includes("snapdragon")) {
      return (
        "NeuroEdge AI is designed around three principles:\n\n" +
        "1. **Private by Design** – sensitive data is processed locally\n" +
        "2. **Fast by Design** – Snapdragon NPU/GPU/CPU acceleration\n" +
        "3. **Multimodal by Design** – text, voice, image, and documents\n\n" +
        "In a real Snapdragon deployment the LLM, vision, ASR, and OCR models run quantized on the Hexagon NPU for maximum speed and efficiency."
      );
    }

    // Generic intelligent reply
    return (
      `I received your request: “${prompt.slice(0, 140)}${prompt.length > 140 ? "…" : ""}”\n\n` +
      "As a fully on-device assistant I can reason over your input, combine it with any attached image or document, " +
      "and respond without transmitting data to external servers.\n\n" +
      "In production this answer would come from a quantized LLM accelerated by Snapdragon AI Engine."
    );
  }

  // Simulated component latencies (ms)
  function simulatePipeline(hasVoice, hasImage, hasDoc) {
    const steps = [];
    if (hasVoice) steps.push({ name: "asr", ms: 280 + Math.random() * 200 });
    if (hasDoc) {
      steps.push({ name: "ocr", ms: 350 + Math.random() * 300 });
      steps.push({ name: "rag", ms: 80 + Math.random() * 60 });
    }
    if (hasImage) steps.push({ name: "vision", ms: 300 + Math.random() * 250 });
    steps.push({ name: "llm", ms: 180 + Math.random() * 280 });
    return steps;
  }

  function setComponentStatus(name, status) {
    const el = document.querySelector(`#component-status div span:first-child`);
    // simpler: update all via text
    const map = { asr: 1, vision: 2, ocr: 3, rag: 4, llm: 0 };
    // rebuild status display
    const container = $("#component-status");
    const components = ["LLM", "ASR", "Vision", "OCR", "RAG"];
    const statuses = {
      LLM: name === "llm" ? status : "idle",
      ASR: name === "asr" ? status : "idle",
      Vision: name === "vision" ? status : "idle",
      OCR: name === "ocr" ? status : "idle",
      RAG: name === "rag" ? status : "idle",
    };
    // keep previous running ones briefly – for demo we just flash
    container.innerHTML = components
      .map(
        (c) =>
          `<div><span>${c}</span><span class="${
            statuses[c] === "running" ? "running" : "idle"
          }">${statuses[c]}</span></div>`
      )
      .join("");
  }

  function updatePerfUI(totalMs, steps) {
    state.stats.total += 1;
    state.stats.lastLatency = Math.round(totalMs);
    state.stats.history.push(totalMs);
    if (state.stats.history.length > 20) state.stats.history.shift();
    state.stats.avgLatency = Math.round(
      state.stats.history.reduce((a, b) => a + b, 0) / state.stats.history.length
    );

    $("#last-latency").textContent = state.stats.lastLatency + " ms";
    $("#avg-latency").textContent = state.stats.avgLatency + " ms";
    $("#total-inf").textContent = state.stats.total;
    $("#on-device-ratio").textContent = "100%";
  }

  function showPrivacyToast(msg) {
    privacyToastText.textContent = msg;
    privacyToast.classList.remove("hidden");
    setTimeout(() => privacyToast.classList.add("hidden"), 3200);
  }

  // ---------- UI Helpers ----------
  function addMessage(role, text, meta = {}) {
    const div = document.createElement("div");
    div.className = `message ${role}`;
    const avatar = role === "assistant" ? "NE" : "You";

    let metaHtml = "";
    if (role === "assistant") {
      metaHtml = `
        <div class="meta">
          <span class="badge on-device">🔒 On-Device</span>
          ${meta.latency ? `<span class="badge latency">${meta.latency} ms</span>` : ""}
          ${meta.components ? `<span class="badge latency">${meta.components}</span>` : ""}
        </div>`;
    }

    // simple markdown-ish rendering
    const html = text
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
      .replace(/\n/g, "<br>");

    div.innerHTML = `
      <div class="avatar">${avatar}</div>
      <div class="bubble">
        <div>${html}</div>
        ${metaHtml}
      </div>`;
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function renderAttachments() {
    attachmentsEl.innerHTML = "";
    if (state.pendingImage) {
      const chip = document.createElement("div");
      chip.className = "attachment-chip";
      chip.innerHTML = `🖼 ${state.pendingImage.name} <button data-type="image">✕</button>`;
      chip.querySelector("button").onclick = () => {
        state.pendingImage = null;
        renderAttachments();
      };
      attachmentsEl.appendChild(chip);
    }
    if (state.pendingDoc) {
      const chip = document.createElement("div");
      chip.className = "attachment-chip";
      chip.innerHTML = `📄 ${state.pendingDoc.name} <button data-type="doc">✕</button>`;
      chip.querySelector("button").onclick = () => {
        state.pendingDoc = null;
        state.pendingDocText = null;
        renderAttachments();
      };
      attachmentsEl.appendChild(chip);
    }
  }

  // ---------- Core Process ----------
  async function processUserMessage(text) {
    if (state.isProcessing) return;
    state.isProcessing = true;
    sendBtn.disabled = true;

    const hasImage = !!state.pendingImage;
    const hasDoc = !!state.pendingDoc;
    const hasVoice = false; // set by voice path

    // Show user message
    let userDisplay = text || "";
    if (hasImage) userDisplay += (userDisplay ? " " : "") + `[Image: ${state.pendingImage.name}]`;
    if (hasDoc) userDisplay += (userDisplay ? " " : "") + `[Document: ${state.pendingDoc.name}]`;
    if (!userDisplay) userDisplay = hasImage ? "Analyze this image" : "Summarize this document";

    addMessage("user", userDisplay);

    // Simulate pipeline with realistic delays
    const steps = simulatePipeline(hasVoice, hasImage, hasDoc);
    let totalMs = 0;

    for (const step of steps) {
      setComponentStatus(step.name, "running");
      await sleep(step.ms);
      totalMs += step.ms;
      setComponentStatus(step.name, "idle");
    }

    // Generate answer
    const answer = mockLLM(text || userDisplay, {
      hasImage,
      docText: state.pendingDocText,
    });

    const components = steps.map((s) => s.name).join(" → ");
    addMessage("assistant", answer, {
      latency: Math.round(totalMs),
      components,
    });

    updatePerfUI(totalMs, steps);
    showPrivacyToast("🔒 All processing performed on-device. No data left this device.");

    // Clear attachments after processing
    state.pendingImage = null;
    state.pendingDoc = null;
    state.pendingDocText = null;
    renderAttachments();

    state.isProcessing = false;
    sendBtn.disabled = false;
    inputEl.focus();
  }

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  // ---------- Event Handlers ----------
  sendBtn.addEventListener("click", () => {
    const text = inputEl.value.trim();
    if (!text && !state.pendingImage && !state.pendingDoc) return;
    inputEl.value = "";
    processUserMessage(text);
  });

  inputEl.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendBtn.click();
    }
  });

  imgBtn.addEventListener("click", () => imgInput.click());
  docBtn.addEventListener("click", () => docInput.click());

  imgInput.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    state.pendingImage = file;
    renderAttachments();
    e.target.value = "";
  });

  docInput.addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    state.pendingDoc = file;
    // Read text content for demo (real OCR would happen in pipeline)
    if (file.type.startsWith("text/") || file.name.endsWith(".md") || file.name.endsWith(".txt") || file.name.endsWith(".csv") || file.name.endsWith(".json")) {
      state.pendingDocText = await file.text();
    } else {
      state.pendingDocText = "PDF content would be extracted via on-device OCR.";
    }
    renderAttachments();
    e.target.value = "";
  });

  // Voice (Web Speech API)
  let recognition = null;
  if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";

    recognition.onstart = () => {
      voiceBtn.classList.add("recording");
    };
    recognition.onend = () => {
      voiceBtn.classList.remove("recording");
    };
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      inputEl.value = transcript;
      processUserMessage(transcript);
    };
    recognition.onerror = () => {
      voiceBtn.classList.remove("recording");
    };

    voiceBtn.addEventListener("click", () => {
      if (voiceBtn.classList.contains("recording")) {
        recognition.stop();
      } else {
        recognition.start();
      }
    });
  } else {
    voiceBtn.title = "Speech recognition not supported in this browser";
    voiceBtn.addEventListener("click", () => {
      alert("Web Speech API is not available in this browser. Try Chrome or Edge.");
    });
  }

  clearBtn.addEventListener("click", () => {
    messagesEl.innerHTML = "";
    addMessage(
      "assistant",
      "Conversation cleared. I’m still running fully on-device and ready for your next request."
    );
    state.stats = { lastLatency: 0, avgLatency: 0, total: 0, onDeviceRatio: 1, history: [] };
    $("#last-latency").textContent = "— ms";
    $("#avg-latency").textContent = "— ms";
    $("#total-inf").textContent = "0";
  });

  // Focus input on load
  inputEl.focus();
})();
