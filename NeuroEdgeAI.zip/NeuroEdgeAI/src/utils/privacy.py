"""
Privacy utilities – surface on-device status to the user.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import List


@dataclass
class PrivacyStatus:
    on_device: bool
    components: List[str]
    message: str
    level: str  # "full" | "partial" | "cloud"


def get_privacy_status(components_used: List[str], all_on_device: bool = True) -> PrivacyStatus:
    if all_on_device:
        return PrivacyStatus(
            on_device=True,
            components=components_used,
            message="All processing performed on-device. No data left this device.",
            level="full",
        )
    return PrivacyStatus(
        on_device=False,
        components=components_used,
        message="Some components required cloud fallback. Sensitive data may have been transmitted.",
        level="partial",
    )


def privacy_badge_html(status: PrivacyStatus) -> str:
    color = "#10b981" if status.level == "full" else "#f59e0b"
    icon = "🔒" if status.level == "full" else "⚠️"
    return f"""
    <div class="privacy-badge" style="border-color:{color}">
        <span>{icon}</span>
        <span>{status.message}</span>
    </div>
    """
