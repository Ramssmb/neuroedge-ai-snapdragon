"""
Hardware detection and Snapdragon acceleration helpers.
In real deployment this would query Qualcomm AI Engine / Android System properties.
"""

from __future__ import annotations
import platform
import os
from typing import Dict, Optional


def detect_platform() -> Dict[str, str]:
    """Return basic platform info. On real Snapdragon device this would report NPU presence."""
    return {
        "system": platform.system(),
        "machine": platform.machine(),
        "processor": platform.processor() or "unknown",
        "python": platform.python_version(),
        "snapdragon_detected": _check_snapdragon_hints(),
        "acceleration_available": False,  # set True when QNN/SNPE is linked
    }


def _check_snapdragon_hints() -> bool:
    """Heuristic checks that would be replaced by real Qualcomm APIs on device."""
    # On Android these would come from Build.HARDWARE, ro.board.platform, etc.
    hints = [
        os.environ.get("SNAPDRAGON", ""),
        os.environ.get("QUALCOMM_AI", ""),
        platform.machine().lower(),
    ]
    return any("snap" in h or "qcom" in h or "qualcomm" in h for h in hints)


def get_acceleration_backend() -> str:
    """
    Preferred order on real Snapdragon hardware:
    1. QNN (Qualcomm Neural Network) / AI Engine Direct
    2. SNPE
    3. ONNX Runtime + Qualcomm EP
    4. CPU fallback
    """
    if _check_snapdragon_hints():
        return "qnn"  # or "snpe"
    return "cpu"


def recommend_model_format() -> str:
    backend = get_acceleration_backend()
    if backend in ("qnn", "snpe"):
        return "INT8 / INT4 quantized (QNN or SNPE DLC)"
    return "ONNX or TorchScript (CPU)"
