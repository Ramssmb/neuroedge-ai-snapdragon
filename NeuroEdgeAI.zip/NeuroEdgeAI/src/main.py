#!/usr/bin/env python3
"""
NeuroEdge AI – Command-line prototype
Demonstrates the full multimodal pipeline.
"""

from __future__ import annotations
import sys
import os

# Allow running from project root
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.orchestration.engine import engine
from src.utils.hardware import detect_platform, recommend_model_format
from src.monitoring.performance import monitor


def print_banner():
    print(
        """
╔══════════════════════════════════════════════════════════╗
║             NeuroEdge AI  –  On-Device Assistant         ║
║         Private • Multimodal • Snapdragon-Ready          ║
╚══════════════════════════════════════════════════════════╝
"""
    )
    hw = detect_platform()
    print(f"Platform          : {hw['system']} / {hw['machine']}")
    print(f"Snapdragon hints  : {hw['snapdragon_detected']}")
    print(f"Recommended fmt   : {recommend_model_format()}")
    print("-" * 60)
    print("Commands:  type your message  |  /image <path>  |  /doc <path>")
    print("           /stats  |  /quit")
    print("-" * 60)


def main():
    print_banner()

    while True:
        try:
            user = input("\nYou › ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if not user:
            continue
        if user.lower() in ("/quit", "/exit", "quit", "exit"):
            print("Session ended. All processing stayed on-device.")
            break
        if user.lower() == "/stats":
            import json
            print(json.dumps(monitor.get_summary(), indent=2))
            continue

        image_path = None
        doc_path = None
        text = user

        if user.startswith("/image "):
            image_path = user[7:].strip()
            text = "Describe this image in detail."
        elif user.startswith("/doc "):
            doc_path = user[5:].strip()
            text = "Summarize this document and extract key points and deadlines."

        response = engine.process(
            text=text,
            image_path=image_path,
            document_path=doc_path,
        )

        print("\nNeuroEdge ›")
        print(response.answer)
        print()
        print(f"  [{response.input_type.upper()}]  "
              f"components: {', '.join(response.components_used)}  |  "
              f"on-device: {response.privacy['level']}  |  "
              f"last latency: {response.performance.get('last_latency_ms', 0)} ms")


if __name__ == "__main__":
    main()
