"""
Performance Monitoring Module
Tracks inference latency, memory, and hardware utilization.
Designed to surface Snapdragon NPU/GPU/CPU metrics when available.
"""

from __future__ import annotations
import time
import threading
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from collections import deque


@dataclass
class InferenceMetric:
    component: str
    latency_ms: float
    timestamp: float
    model_name: str = ""
    on_device: bool = True
    extra: Dict = field(default_factory=dict)


class PerformanceMonitor:
    """Thread-safe performance tracker for the entire pipeline."""

    def __init__(self, max_history: int = 100):
        self._lock = threading.Lock()
        self.history: deque[InferenceMetric] = deque(maxlen=max_history)
        self.current_status: Dict[str, str] = {
            "llm": "idle",
            "asr": "idle",
            "vision": "idle",
            "ocr": "idle",
            "rag": "idle",
        }
        self.session_start = time.time()

    def record(self, component: str, latency_ms: float, model_name: str = "", on_device: bool = True, **extra):
        metric = InferenceMetric(
            component=component,
            latency_ms=latency_ms,
            timestamp=time.time(),
            model_name=model_name,
            on_device=on_device,
            extra=extra,
        )
        with self._lock:
            self.history.append(metric)
            self.current_status[component] = "idle"

    def set_status(self, component: str, status: str):
        with self._lock:
            self.current_status[component] = status

    def get_summary(self) -> Dict:
        with self._lock:
            if not self.history:
                return {
                    "avg_latency_ms": 0.0,
                    "last_latency_ms": 0.0,
                    "total_inferences": 0,
                    "on_device_ratio": 1.0,
                    "status": dict(self.current_status),
                    "uptime_s": time.time() - self.session_start,
                }

            latencies = [m.latency_ms for m in self.history]
            on_device_count = sum(1 for m in self.history if m.on_device)

            return {
                "avg_latency_ms": round(sum(latencies) / len(latencies), 1),
                "last_latency_ms": round(latencies[-1], 1),
                "total_inferences": len(self.history),
                "on_device_ratio": round(on_device_count / len(self.history), 2),
                "status": dict(self.current_status),
                "uptime_s": round(time.time() - self.session_start, 1),
                "recent": [
                    {
                        "component": m.component,
                        "latency_ms": round(m.latency_ms, 1),
                        "model": m.model_name,
                        "on_device": m.on_device,
                    }
                    for m in list(self.history)[-5:]
                ],
            }

    def context(self, component: str, model_name: str = ""):
        """Context manager for automatic timing."""
        return _TimerContext(self, component, model_name)


class _TimerContext:
    def __init__(self, monitor: PerformanceMonitor, component: str, model_name: str):
        self.monitor = monitor
        self.component = component
        self.model_name = model_name
        self.start = 0.0

    def __enter__(self):
        self.monitor.set_status(self.component, "running")
        self.start = time.perf_counter()
        return self

    def __exit__(self, *args):
        latency = (time.perf_counter() - self.start) * 1000
        self.monitor.record(self.component, latency, self.model_name, on_device=True)


# Global singleton
monitor = PerformanceMonitor()
