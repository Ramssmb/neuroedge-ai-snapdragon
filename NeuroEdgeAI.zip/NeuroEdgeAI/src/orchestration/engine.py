"""
AI Orchestration Engine
Routes every user request through the correct pipeline and returns
a structured response with privacy + performance metadata.
"""

from __future__ import annotations
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, asdict

from src.orchestration.router import InputType, detect_input_type
from src.models.llm import llm
from src.models.asr import asr
from src.models.vision import vision
from src.models.ocr import ocr
from src.rag.pipeline import rag
from src.monitoring.performance import monitor
from src.utils.privacy import get_privacy_status


@dataclass
class NeuroResponse:
    answer: str
    input_type: str
    components_used: List[str]
    privacy: Dict[str, Any]
    performance: Dict[str, Any]
    on_device: bool = True

    def to_dict(self) -> Dict:
        return asdict(self)


class OrchestrationEngine:
    """Central brain of NeuroEdge AI."""

    def __init__(self):
        self.conversation_history: List[Dict[str, str]] = []

    def process(
        self,
        text: Optional[str] = None,
        audio_path: Optional[str] = None,
        image_path: Optional[str] = None,
        document_path: Optional[str] = None,
        document_text: Optional[str] = None,
    ) -> NeuroResponse:
        components: List[str] = []
        input_type = detect_input_type(
            text=text,
            has_audio=bool(audio_path),
            has_image=bool(image_path),
            has_document=bool(document_path or document_text),
        )

        # 1. Voice → text
        if audio_path:
            components.append("asr")
            transcribed = asr.transcribe(audio_path)
            text = (text or "") + " " + transcribed
            text = text.strip()

        # 2. Document → extract + index for RAG
        if document_path or document_text:
            components.append("ocr")
            if document_text:
                extracted = document_text
            else:
                extracted = ocr.extract_text(document_path)
            rag.index(extracted)
            components.append("rag")
            if not text:
                text = "Please summarize this document and list the key points and action items."

        # 3. Image → vision analysis
        vision_context = ""
        if image_path:
            components.append("vision")
            analysis = vision.analyze(image_path)
            vision_context = (
                f"[Image analysis]\n"
                f"Description: {analysis['description']}\n"
                f"Tags: {', '.join(analysis['tags'])}\n"
            )
            if not text:
                text = "Describe what you see in this image and identify the main objects."

        # 4. Build final prompt and call LLM
        components.append("llm")
        full_prompt = text or "Hello"
        if vision_context:
            full_prompt = vision_context + "\nUser question: " + full_prompt

        # If we have indexed a document, prefer RAG
        if rag.chunks and (document_path or document_text):
            answer = rag.answer(full_prompt)
        else:
            answer = llm.generate(full_prompt)

        # Update conversation history
        self.conversation_history.append({"role": "user", "content": full_prompt})
        self.conversation_history.append({"role": "assistant", "content": answer})

        privacy = get_privacy_status(components, all_on_device=True)
        perf = monitor.get_summary()

        return NeuroResponse(
            answer=answer,
            input_type=input_type.value,
            components_used=components,
            privacy={
                "on_device": privacy.on_device,
                "level": privacy.level,
                "message": privacy.message,
            },
            performance=perf,
            on_device=True,
        )


# Global engine instance
engine = OrchestrationEngine()
