"""
Input type detection and routing decisions.
"""

from __future__ import annotations
from enum import Enum
from typing import Optional


class InputType(str, Enum):
    TEXT = "text"
    VOICE = "voice"
    IMAGE = "image"
    DOCUMENT = "document"
    MULTIMODAL = "multimodal"


def detect_input_type(
    text: Optional[str] = None,
    has_audio: bool = False,
    has_image: bool = False,
    has_document: bool = False,
) -> InputType:
    modalities = sum([bool(text), has_audio, has_image, has_document])
    if modalities > 1:
        return InputType.MULTIMODAL
    if has_audio:
        return InputType.VOICE
    if has_image:
        return InputType.IMAGE
    if has_document:
        return InputType.DOCUMENT
    return InputType.TEXT
