"""
Simple RAG pipeline for document Q&A.
Chunks → Embed → Retrieve → Augment LLM prompt.
"""

from __future__ import annotations
from typing import List, Tuple
from src.models.embeddings import embeddings
from src.models.llm import llm


def chunk_text(text: str, chunk_size: int = 400, overlap: int = 50) -> List[str]:
    words = text.split()
    chunks = []
    i = 0
    while i < len(words):
        chunk = " ".join(words[i : i + chunk_size])
        chunks.append(chunk)
        i += chunk_size - overlap
    return chunks or [text]


def cosine_sim(a: List[float], b: List[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = sum(x * x for x in a) ** 0.5
    nb = sum(x * x for x in b) ** 0.5
    if na * nb == 0:
        return 0.0
    return dot / (na * nb)


class RAGPipeline:
    def __init__(self):
        self.chunks: List[str] = []
        self.vectors: List[List[float]] = []

    def index(self, document_text: str):
        self.chunks = chunk_text(document_text)
        self.vectors = embeddings.embed(self.chunks)

    def retrieve(self, query: str, top_k: int = 3) -> List[str]:
        if not self.chunks:
            return []
        q_vec = embeddings.embed_query(query)
        scored = [(cosine_sim(q_vec, v), i) for i, v in enumerate(self.vectors)]
        scored.sort(reverse=True)
        return [self.chunks[i] for _, i in scored[:top_k]]

    def answer(self, query: str) -> str:
        context_chunks = self.retrieve(query)
        if not context_chunks:
            return llm.generate(query)

        context = "\n\n---\n\n".join(context_chunks)
        prompt = (
            f"Use the following document excerpts to answer the question. "
            f"If the answer is not present, say so.\n\n"
            f"Document context:\n{context}\n\n"
            f"Question: {query}\n\nAnswer:"
        )
        return llm.generate(prompt)


rag = RAGPipeline()
