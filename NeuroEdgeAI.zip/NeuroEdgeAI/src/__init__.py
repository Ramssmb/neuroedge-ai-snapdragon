"""NeuroEdge AI - On-device multimodal assistant for Snapdragon platforms."""

__version__ = "1.0.0"
__author__ = "NeuroEdge Team"
