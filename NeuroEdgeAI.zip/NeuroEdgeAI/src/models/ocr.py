"""
OCR & Document text extraction.
Production: Tesseract, PaddleOCR, or Qualcomm document AI models on Snapdragon.
"""

from __future__ import annotations
import time
import random
from pathlib import Path
from typing import Optional
from src.monitoring.performance import monitor


class OCREngine:
    def __init__(self, model_name: str = "NeuroEdge-OCR-INT8"):
        self.model_name = model_name
        self.is_ready = True

    def extract_text(self, file_path: str = None, image_bytes: bytes = None) -> str:
        """Extract text from image or PDF page."""
        with monitor.context("ocr", self.model_name):
            time.sleep(random.uniform(0.3, 0.8))

            # Realistic mock for demo
            return (
                "CONFIDENTIAL DOCUMENT – FOR INTERNAL USE ONLY\n\n"
                "Project: NeuroEdge AI Evaluation\n"
                "Date: 14 September 2026\n"
                "Author: Edge AI Team\n\n"
                "1. Executive Summary\n"
                "This document outlines the requirements and success criteria for "
                "on-device multimodal AI assistants running on Snapdragon platforms.\n\n"
                "2. Key Requirements\n"
                "• Privacy: no unnecessary cloud transmission of user data\n"
                "• Latency: sub-second response for common queries\n"
                "• Multimodal: text, voice, image, and document support\n\n"
                "3. Action Items\n"
                "• Finalize model quantization by end of month\n"
                "• Complete performance benchmarking on target hardware\n"
                "• Prepare demo for stakeholders\n\n"
                "End of extracted text."
            )

    def extract_from_pdf(self, pdf_path: str) -> str:
        """Placeholder for multi-page PDF extraction."""
        return self.extract_text(pdf_path)


ocr = OCREngine()
