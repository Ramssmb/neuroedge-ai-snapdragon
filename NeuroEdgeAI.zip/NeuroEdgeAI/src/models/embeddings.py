"""
Embedding model for RAG.
Production: all-MiniLM or similar quantized model on Snapdragon.
"""

from __future__ import annotations
import time
import random
import hashlib
from typing import List
from src.monitoring.performance import monitor


class EmbeddingModel:
    def __init__(self, model_name: str = "NeuroEdge-Embed-MiniLM-INT8"):
        self.model_name = model_name
        self.dim = 384

    def embed(self, texts: List[str]) -> List[List[float]]:
        with monitor.context("rag", self.model_name):
            time.sleep(0.05 * len(texts))
            # Deterministic fake embeddings for demo (hash-based)
            vectors = []
            for t in texts:
                h = hashlib.sha256(t.encode()).digest()
                vec = [((b / 255.0) - 0.5) for b in h[: self.dim]]
                # pad if needed
                while len(vec) < self.dim:
                    vec.append(0.0)
                vectors.append(vec[: self.dim])
            return vectors

    def embed_query(self, query: str) -> List[float]:
        return self.embed([query])[0]


embeddings = EmbeddingModel()
