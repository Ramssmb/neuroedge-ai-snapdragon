"""
Speech Recognition (ASR) engine.
Production: Whisper-tiny / base quantized or Qualcomm's on-device ASR running on Snapdragon.
"""

from __future__ import annotations
import time
import random
from src.monitoring.performance import monitor


class SpeechRecognizer:
    def __init__(self, model_name: str = "NeuroEdge-Whisper-tiny-INT8"):
        self.model_name = model_name
        self.is_ready = True

    def transcribe(self, audio_path: str = None, audio_bytes: bytes = None) -> str:
        """Convert speech to text. In real use, accept WAV/PCM or microphone stream."""
        with monitor.context("asr", self.model_name):
            time.sleep(random.uniform(0.2, 0.6))
            # Mock transcription for demo
            return "This is a simulated transcription of the user's spoken request. In production this would be real Whisper or Snapdragon ASR output."

    def transcribe_stream(self, chunk: bytes) -> str:
        """Streaming recognition placeholder."""
        return self.transcribe()


asr = SpeechRecognizer()
