# NeuroEdge AI – Technical Architecture

## High-Level Pipeline

```
User Input (Text / Voice / Image / Document)
        │
        ▼
┌───────────────────────┐
│  AI Orchestration     │
│  Engine               │
│  (router + pipeline)  │
└───────────┬───────────┘
            │
    ┌───────┼───────┬──────────┬──────────┐
    ▼       ▼       ▼          ▼          ▼
  ASR     Vision   OCR      Embeddings   Local LLM
 (voice)  (image) (doc)      (RAG)      (reasoning)
    │       │       │          │          │
    └───────┴───────┴──────────┴──────────┘
                    │
                    ▼
            Intelligent Response
            + Privacy Badge
            + Performance Metrics
```

## Component Responsibilities

| Component          | Responsibility                              | Snapdragon Target      |
|--------------------|---------------------------------------------|------------------------|
| Orchestration      | Route inputs, combine modalities, manage state | CPU                    |
| Local LLM          | Reasoning, generation, chat                 | Hexagon NPU (INT4/8)   |
| ASR                | Speech → text                               | NPU / DSP              |
| Vision             | Image understanding, object detection       | NPU / GPU              |
| OCR                | Text extraction from images/PDFs            | NPU / CPU              |
| Embeddings + RAG   | Document chunking, retrieval, context       | NPU                    |
| Performance Monitor| Latency, status, hardware counters          | System APIs            |

## Privacy Flow

Every response includes a `privacy` object:

```json
{
  "on_device": true,
  "level": "full",
  "message": "All processing performed on-device. No data left this device."
}
```

The UI always surfaces this badge so the user trusts the system.

## Extension Points

- Replace any class in `src/models/` with a real Qualcomm-accelerated implementation
- Add new modalities by extending `InputType` and the orchestration engine
- Persist conversation history locally (encrypted) for personalized memory
