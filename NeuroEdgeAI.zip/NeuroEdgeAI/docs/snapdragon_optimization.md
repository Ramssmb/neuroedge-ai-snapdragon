# Snapdragon Optimization Guide

## Recommended Stack (2026)

1. **Model Preparation**
   - Start with small, high-quality models: Phi-3-mini, Gemma-2B, Llama-3.2-1B/3B, Whisper-tiny
   - Quantize to INT8 or INT4 using Qualcomm AI Hub or ONNX quantizer
   - Validate accuracy drop is acceptable for the target use-case

2. **Runtime Options (in order of preference)**
   - Qualcomm AI Engine Direct / QNN
   - SNPE (Snapdragon Neural Processing Engine)
   - ONNX Runtime with Qualcomm Execution Provider
   - TensorFlow Lite + Hexagon delegate

3. **Key Metrics to Measure on Device**
   - Time-to-first-token (TTFT)
   - Tokens per second
   - Peak memory (RSS)
   - NPU / GPU / CPU utilization
   - Power draw (mW) during inference
   - Cold-start latency

4. **Android Integration Tips**
   - Use CameraX + ML Kit or custom NPU path for vision
   - AudioRecord + streaming ASR
   - Jetpack Compose for the UI (mirror the web prototype layout)
   - Expose a simple JNI or Kotlin API that calls the same orchestration logic

5. **Model Placement**
   Place optimized `.dlc`, `.bin`, or `.onnx` files under `models/` and update the constructors in `src/models/*` to load them via the chosen runtime.

## Current Prototype Status

The Python code uses realistic mock latencies and deterministic responses so the full pipeline can be demonstrated without Snapdragon hardware.  
Replacing the `generate()`, `transcribe()`, `analyze()`, and `extract_text()` methods with real accelerated calls is the only change required for production.
