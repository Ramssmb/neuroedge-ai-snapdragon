# Android + Snapdragon Port Notes

This folder is a placeholder for the future native Android application.

## Recommended Approach

1. **UI**: Jetpack Compose (mirror the layout of `web/index.html`)
2. **Orchestration**: Port `src/orchestration/engine.py` logic to Kotlin
3. **Models**:
   - Load quantized models via Qualcomm AI Engine Direct / QNN
   - Or ONNX Runtime Android with Qualcomm EP
4. **Permissions**: CAMERA, RECORD_AUDIO, READ_EXTERNAL_STORAGE / MediaStore
5. **Performance**: Use Android System Tracing + Qualcomm profiling tools

## Minimum Viable Android Demo

- Text chat with local LLM
- Image capture → vision model → LLM
- Document picker → OCR → RAG → LLM
- Always show the on-device privacy badge
- Live latency numbers in a side panel

The Python and web prototypes already implement the exact same pipeline so the Android port can reuse the same response contracts.
